/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.personspecter;

/**
 *
 * @author zainali
 */
public class ComMycompanyPersonspecter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame0 labelFrame = new JFrame0(); 
        labelFrame.setDefaultCloseOperation(JFrame0.EXIT_ON_CLOSE);
        labelFrame.setVisible(true);
    }
    
}
