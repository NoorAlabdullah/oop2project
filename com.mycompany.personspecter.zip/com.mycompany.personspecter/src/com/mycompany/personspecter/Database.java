/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.personspecter;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Iqbal Siddique
 */
public class Database 
{
    // JDBC URL, username and password of MySQL server
    private static final String url = "jdbc:mysql://localhost:3306/PearsonSpector";
    private static final String user = "root";
    private static final String password = "Qq-130130";

    // JDBC variables for opening and managing connection
    private static Connection con;
    private static PreparedStatement pst;
    private static ResultSet rs;
    int id, q, m;
    
    Database()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection(url,user,password);
            //pst=con.prepareStatement("select Email,Pass from CLIENT where Email=? and Pass=?");
        }
        
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
    public Boolean checkLogin(String email,String pwd)
    {
        try 
        {
            pst=con.prepareStatement("select Email,Pass from CLIENT where Email=? and Pass=?");
            pst.setString(1, email); //this replaces the 1st  "?" in the query for username
            pst.setString(2, pwd);    //this replaces the 2st  "?" in the query for password
            //executes the prepared statement
            rs=pst.executeQuery();
            
            if(rs.next())
            {
                //TRUE iff the query founds any corresponding data
                return true;
            }
            else
            {
                return false;
            }
        } 
        
        catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("error while validating"+e);
            return false;
        }
    }
    
    public Boolean check_Employee_Login(String email,String pwd)
    {
        try 
        {
            pst=con.prepareStatement("select Email,Pass from EMPLOYEE where Email=? and Pass=?");
            pst.setString(1, email); //this replaces the 1st  "?" in the query for username
            pst.setString(2, pwd);    //this replaces the 2st  "?" in the query for password
            //executes the prepared statement
            rs=pst.executeQuery();
            if(rs.next())
            {
                //TRUE iff the query founds any corresponding data
                return true;
            }
            else
            {
                return false;
            }
        } 
        catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("error while validating"+e);
            return false;
        }
    }
    public Boolean check_Manager_Login(String email,String pwd)
    {
        try 
        {
            pst= con.prepareStatement("select Email,Pass from MANAGER where Email=? and Pass=?");
            pst.setString(1, email); //this replaces the 1st  "?" in the query for username
            pst.setString(2, pwd);    //this replaces the 2nd  "?" in the query for password
            //executes the prepared statement
            rs=pst.executeQuery();
            if(rs.next())
            {
                //TRUE iff the query founds any corresponding data
                return true;
            }
            else
            {
                return false;
            }
        } 
        catch (SQLException e) 
        {
            // TODO Auto-generated catch block
            System.out.println("error while validating"+e);
            return false;
        }
    }
    
    public Boolean registerUser(String fname,String lname,String pwd,String gender,String email,String phone,String region,String city,String street)
    {
        try 
        {
            pst=con.prepareStatement("insert into CLIENT(C_Fname,C_Lname,PhonNum,Email,Pass,Gender,Regin,City,Street) values(?,?,?,?,?,?,?,?,?)");
            pst.setString(1,fname);
            pst.setString(2,lname);
            pst.setString(3,phone);
            pst.setString(4,email);
            pst.setString(5,pwd);
            pst.setString(6,gender);
            pst.setString(7,region);
            pst.setString(8,city);
            pst.setString(9,street);

            pst.executeUpdate();
            return true; 
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Boolean registerEmployee(String fname,String lname,String pwd,String gender,String email,String phone,String region,String city,String street, String salary)
    {
        try 
        {
            pst=con.prepareStatement("insert into  Employee(E_Fname, E_Lname, Salary, PhonNum, Email, Pass, Gender, R_year, Regin, City, Street)   values(?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1,fname);
            pst.setString(2,lname);
            pst.setString(3,salary);
            pst.setString(4,phone);
            pst.setString(5,email);
            pst.setString(6,pwd);
            pst.setString(7,gender);
            pst.setString(8,region);
            pst.setString(9,city);
            pst.setString(10,street);

            pst.executeUpdate();
            return true; 
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Boolean registerItem(String Iname,String Iprice,String INO)
    {
        try 
        {
            pst=con.prepareStatement("INSERT INTO  ITEM (I_name, Price, Num_Itme) values(?,?,?)");
            pst.setString(1,Iname);
            pst.setString(2,Iprice);
            pst.setString(3,INO);

            pst.executeUpdate();
            return true; 
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Boolean place_order(int id,int amount)
    {
        try {
                String status="pending";
                pst=con.prepareStatement("insert into ORDERS(Amount,Stat,C_ID) values(?,?,?)");
                pst.setString(1,amount+"");
                pst.setString(2,status);
                pst.setString(3,id+"");
            
   
                pst.executeUpdate();
                return true;
            
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Boolean add_complain(int id,String complain)
    {
        try {
            
                pst=con.prepareStatement("insert into complaints(compain,Client_ID) values(?,?)");
                pst.setString(1,complain+"");
                pst.setString(2,id+"");
            
   
                pst.executeUpdate();
                return true;
            
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    public String show_complain()
    {
        String s="";
        try 
        { 
            pst=con.prepareStatement("SELECT compain from complaints");
            
            rs=pst.executeQuery();
            while(rs.next())
            {
               s += rs.getString(1)+"\n---------------------------------------------------------\n";
            }
            System.out.println(s);
            
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
    }
    
    
    public int getUserId(String email)
    {
        int id=0;
        try {
            pst=con.prepareStatement("Select C_ID from CLIENT where Email=?");
            pst.setString(1,email);
            
            rs=pst.executeQuery();
            while(rs.next())
            {
               id=rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }
    
    String show_orders(){
        String s="";
        try {
            pst=con.prepareStatement("SELECT ORDERS.O_ID,ORDERS.Amount,ORDERS.Stat,CLIENT.C_Fname, CLIENT.City FROM ORDERS,CLIENT WHERE ORDERS.C_ID=CLIENT.C_ID and ORDERS.Stat=?");
            pst.setString(1,"pending");
            
            rs=pst.executeQuery();
            while(rs.next())
            {
               s += rs.getInt(1)+"\t\t"+rs.getString(4)+"\t\t"+rs.getString(5)+"\t\t"+rs.getInt(2)+"\t"+rs.getString(3)+"\n";
            }
            System.out.println(s);
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
    }
    
    void change_status(int id){
        try {
            pst=con.prepareStatement("update ORDERS set Stat=? where O_ID=?");
            pst.setString(1,"delivered");
            pst.setString(2, id+"");
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
//    public void update_item(String name, String price, String amount)
//    {
//        try {
//            pst=con.prepareStatement("SELECT * FROM ITEM");
//            pst.setString(1,"delivered");
//            pst.setString(2, id+"");
//            pst.executeUpdate();
//            
//            rs= pst.executeQuery();
//            java.sql.ResultSetMetaData stData= rs.getMetaData();
//            
//            q= stData.getColumnCount();
//            
//            //var recordTable= (DefaultTableModel)jTable1.getModel();
//            DefaultTableModel recordTable= (DefaultTableModel)jTable1.getModel();
//            
//            recordTable.setRowCount(0);
//            
//            while (rs.next())
//            {
//                
//            }
//            
//            
//        } catch (SQLException ex) {
//            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
}
